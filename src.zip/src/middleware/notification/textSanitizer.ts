const EOS_TOKEN = '<|eos|>';

/**
 * Cleans raw model output into a single plain-text notification body.
 *
 * Plain-text cleanup, not JSON parsing - the model was trained to continue
 * free text after "Notification:", not to emit structured output.
 */
export function sanitizeOutput(rawOutput: string, prompt: string): string {
  let text = rawOutput;

  // Some runtimes echo the prompt back with the completion.
  if (text.startsWith(prompt)) {
    text = text.slice(prompt.length);
  }

  // Cut at the first sign the model finished or started a new example:
  // the EOS marker, a newline, or a fresh "Context:" block.
  const cutPoints = [EOS_TOKEN, '\n', 'Context:']
    .map((marker) => text.indexOf(marker))
    .filter((i) => i !== -1);
  if (cutPoints.length > 0) {
    text = text.slice(0, Math.min(...cutPoints));
  }

  return text.replace(/^\s*Notification:\s*/i, '').replace(/\s+/g, ' ').trim();
}
